import ssl
import socket

# WARNING: This is only for testing purposes and should not be used in production
context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

# Start a connection to the server
with socket.create_connection(('localhost', 4443)) as sock:
    with context.wrap_socket(sock, server_hostname='localhost') as ssock:
        print("SSL connection established using:", ssock.version())

        while True:  # Loop to send messages entered by the user
            try:
                # Get message input from the user
                message = input("Enter your message to the server: ")
                if message.lower() == 'exit':
                    print("Exiting.")
                    break

                # Send the message to the server
                ssock.sendall(message.encode('utf-8'))

                # Wait for a response from the server and print it out
                response = ssock.recv(4096)
                print("Received from server:", response.decode('utf-8'))

            except (ConnectionResetError, ConnectionAbortedError):
                print("Connection lost with the server.")
                break
            except KeyboardInterrupt:
                print("\nInterrupted by the user.")
                break

