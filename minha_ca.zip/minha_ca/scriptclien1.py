import ssl
import socket

# Configure SSL context to verify the server
context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile='certificados/servidor.cert')
context.load_cert_chain(certfile='certificados/utilizador.cert.pem', keyfile='privado/utilizador.key.pem')  # If client authentication is required

context.check_hostname = False  # Since we use self-signed, this is typically set to False in local testing

# Connect to the server
with socket.create_connection(('localhost', 4443)) as sock:
    with context.wrap_socket(sock, server_hostname='localhost') as ssock:
        print("SSL connection established using:", ssock.version())

        # Sending a message to the server
        message = "Hello, server! How are you today?"
        ssock.sendall(message.encode('utf-8'))

        # Waiting for a response from the server
        response = ssock.recv(4096)
        print("Received from server:", response.decode('utf-8'))
