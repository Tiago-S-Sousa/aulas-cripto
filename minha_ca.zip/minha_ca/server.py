import socket
import ssl

# Create a socket for the server
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 4443))
server_socket.listen(5)

# Create an SSL context
context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
context.load_cert_chain(certfile='certificados/servidor.cert', keyfile='privado/servidor.key')

print("Server running on https://localhost:4443")

while True:  # Server loop to accept connections
    try:
        # Accept a connection
        client_socket, addr = server_socket.accept()
        print(f"Accepted connection from {addr}")

        # Wrap the client's socket with SSL
        ssock = context.wrap_socket(client_socket, server_side=True)

        while True:  # Loop to read messages from the client
            # Read data from the client and decode it
            data = ssock.recv(1024).decode('utf-8')
            if data:
                print(f"Received from client: {data}")
                # Send a response back to the client
                response = "Server received your message: " + data
                ssock.sendall(response.encode('utf-8'))
            else:
                print("No more data from client. Closing connection.")
                break

    except ssl.SSLError as e:
        print(f"SSL error: {e}")

    except Exception as e:
        print(f"Server error: {e}")

    finally:
        # Close the client's socket
        ssock.close()

    # Uncomment the below line if the server should only accept a single connection
    # break
